import React from 'react';
import {BrowserRouter as Router, Route, Switch, useHistory} from 'react-router-dom';

import Sidebar from './layout/admin/Sidebar';
import Navbar from './layout/admin/Navbar';
import Footer from './layout/admin/Footer'

//import 'bootstrap'
//import 'bootstrap'
//import 'react-bootstrap'
import "../src/assets/admin/css/styles.css"
import '../src/assets/admin/js/scripts'
import Profile from './components/report/Profile';


function App() {
  const history=useHistory();
  
  
  return (
    <div className="App">
    <Router history={history}>
     <Switch>
      
          {/* <Route exact name="Home" path='/' component={Login}/>  */}
          <div className="sb-nav-fixed">
            <Navbar/>
            <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
              <Sidebar/>
              </div>
              <div id="layoutSidenav_content">
               <main>
        
       
               <Route exact name="Profile" path='/' component={Profile}/> 
         
        </main>
        <Footer/>
        </div>
        
      </div>
    

  </div>
          <Route path='*'>
             
              404 not found
          </Route>          
      </Switch>
  </Router>
    </div>
  );
}

export default App;
